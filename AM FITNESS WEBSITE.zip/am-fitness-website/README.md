# A.M Fitness website

Single-page site. Everything (HTML, CSS, JavaScript, photo and logo) lives inside `index.html`,
so there are no external files or paths to break. No fonts to install (system fonts are used).

- `assets/` holds your original full-size photo and logo as backups. The site does not load them.
- `netlify.toml` tells Netlify to publish this folder as-is.

## Deploy
GitHub: create a repo, upload these files. Netlify: Add new site > Import from Git > pick the repo (no build command, publish directory `.`).
Or drag this whole folder into Netlify > Deploys.

## Edit mode
Open your live address followed by `?edit` (e.g. yoursite.netlify.app/?edit) to change text, photo, links and prices,
then Save & download and replace `index.html`.

## Before going live
Open `index.html` and fill in WHATSAPP_NUMBER, PAYFAST_LINK, PAYPAL_LINK (and optional TIKTOK_LINK, INSTAGRAM_LINK), or use Settings in edit mode.
